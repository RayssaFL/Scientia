package com.example.scientia

data class UsuarioDetalhes(
    val nome: String,
    val email: String,
    val id: String,
    val quantidadeEmprestimos: Int
)
