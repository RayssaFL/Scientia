package com.example.scientia

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class TelaContato_User : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_tela_contato_user)
    }
}